# pyre-strict

HYPERPARAMETER_NAMES = ("thetas", "shapes", "scales", "alphas", "gammas", "penalty")
